
#include<SDL2/SDL.h>
#include<SDL2/SDL_image.h>
#include<iostream>
#include<fstream>
#include<vector>
SDL_Window* window;
SDL_Renderer* renderer;
SDL_Event Event;
SDL_Texture *background,*character,*character2;
SDL_Rect rect_background,rect_character,rect_character2;

using namespace std;

vector<SDL_Texture*> bee_textures;

SDL_Rect bee_rect;

int current_bee_texture = 0;

bool estaColisionando(SDL_Rect a, SDL_Rect b)

{

    if(a.x + a.w < b.x)

        return false;



    if(b.x + b.w < a.x)

        return false;



    if(b.y + b.h < a.y)

        return false;



    if(a.y + a.h < b.y)

        return false;



    return true;

}


int main( int argc, char* args[] )
{
    //Init SDL
    if(SDL_Init(SDL_INIT_EVERYTHING) < 0)
    {
        return 10;
    }
    //Creates a SDL Window
    if((window = SDL_CreateWindow("Image Loading", 100, 100, 1322/*WIDTH*/, 700/*HEIGHT*/, SDL_WINDOW_RESIZABLE | SDL_RENDERER_PRESENTVSYNC)) == NULL)
    {
        return 20;
    }
    //SDL Renderer
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED );
    if (renderer == NULL)
    {
        std::cout << SDL_GetError() << std::endl;
        return 30;
    }

    //Init textures
    int w=0,h=0;
    background = IMG_LoadTexture(renderer,"fondo.png");
    SDL_QueryTexture(background, NULL, NULL, &w, &h);
    rect_background.x = 0;
    rect_background.y = 0;
    rect_background.w = 1322;
    rect_background.h = 700;

    character = IMG_LoadTexture(renderer, "carro.png");
    SDL_QueryTexture(character, NULL, NULL, &w, &h);
    rect_character.x = 880;
    rect_character.y = 880;
    rect_character.w = w;
    rect_character.h = h;


    character2 = IMG_LoadTexture(renderer, "carro_enemigo.png");
    SDL_QueryTexture(character, NULL, NULL, &w, &h);
    rect_character2.x=450;
    rect_character. y=450;
    rect_character2.w = w;
    rect_character2.h = h;

   bee_textures.push_back(IMG_LoadTexture(renderer, "bee1.png"));

    bee_textures.push_back(IMG_LoadTexture(renderer, "bee2.png"));

    bee_rect.x = 100;

    bee_rect.y = 20;

    bee_rect.w=100;


    SDL_QueryTexture(bee_textures[0], NULL, NULL, &bee_rect.w, &bee_rect.h);

    //Main Loop
    int frames=0;
     char bee_orientation = 'r';

    int velocidad=2;

    while(true)
    {
        while(SDL_PollEvent(&Event))
        {
            if(Event.type == SDL_QUIT)
            {
                return 0;
            }
            if(Event.type == SDL_KEYDOWN)
            {
                if(Event.key.keysym.sym == SDLK_d)
                    rect_character.x++;
            }

            if(Event.type == SDL_QUIT)
            {
                return 0;
            }
            if(Event.type == SDL_KEYDOWN)
            {
                if(Event.key.keysym.sym == SDLK_w)
                    rect_character.y--;
            }


                 if(Event.type == SDL_QUIT)
            {
                return 0;
            }
            if(Event.type == SDL_KEYDOWN)
            {
                if(Event.key.keysym.sym == SDLK_6)
                    rect_character2.x++;
            }

            if(Event.type == SDL_QUIT)
            {
                return 0;
            }
            if(Event.type == SDL_KEYDOWN)
            {
                if(Event.key.keysym.sym == SDLK_8)
                    rect_character2.y++;
            }


        }

if(bee_rect.x>400)

            bee_orientation='l';



        if(bee_rect.x<200)

            bee_orientation='r';



        if(bee_orientation == 'r')

            bee_rect.x+=2;

        if(bee_orientation == 'l')

            bee_rect.x-=2;





        //Animar cuadro x cuadro

        if(frames%10==0)

        {

            current_bee_texture++;

            if(current_bee_texture >= bee_textures.size())

            {

                current_bee_texture = 0;

            }

        }



        frames++;


        SDL_RenderCopy(renderer, background, NULL, &rect_background);
        SDL_RenderCopy(renderer, character, NULL, &rect_character);
        SDL_RenderCopy(renderer, character2, NULL,&rect_character2);
        SDL_RenderCopy(renderer, bee_textures[current_bee_texture], NULL, &bee_rect);
        SDL_RenderPresent(renderer);
        SDL_Delay(1);
    }

    return 0;
}
